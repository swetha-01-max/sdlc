# Google Cloud

A aplicação executa em um projeto no **Google Cloud Platform**.

## Secret Manager
Usado para guardar a APIKEY.  

## Cloud Run
TBD

