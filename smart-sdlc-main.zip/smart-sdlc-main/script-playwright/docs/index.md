# gerar-script-test-case

Aplicação/Serviço em NodeJS + Express para gerar scripts de Testes **Palywright**.
