# image-processor

Aplicação/Serviço em NodeJS + Express para gerar descrição de protótipos de tela a partir de uma imagem.  
