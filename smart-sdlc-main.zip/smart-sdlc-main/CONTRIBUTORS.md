# CONTRIBUTORS

This is a dynamic table that lists all the contributors to this project. If you want to suggest a name to be added here, please, update the list of issues of the repo with that ask.

| Contributor    | Github Username                              | Role          |
| -------------- | -------------------------------------------- | ------------- |
| Marcelo Parisi | [@feitnomore](https://github.com/feitnomore) | Project Admin |