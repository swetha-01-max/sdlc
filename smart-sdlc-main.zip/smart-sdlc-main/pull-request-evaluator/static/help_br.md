    
Estes são os comandos que eu entendo:  

| **command**      | **description**                         |
|------------------|-----------------------------------------|
| /help            | Imprime esta mensagem                   |
| /prSummary       | Imprime o Sumário da Pull Request       |
| /diffSummary     | Imprime o Sumário de cada Diff          |
| /diffRank        | Gera o Ranking de cada Diff             |
| /fileSummary     | Imprime o Sumário de cada Arquivo       |
| /filePerformance | Report de Performance para cada Arquivo |
| /fileSecurity    | Report de Segurança para cada Arquivo   |
    
    