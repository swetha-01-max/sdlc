Hello, I'm **pull-request-evaluator**, your virtual assistant. I'm in experimental phase. 
  
If you have any doubts, questions or suggestions, please contact the responsible team.  
Use `/help` for a simplified help.    
  
Thanks!