Olá, eu sou o **pull-request-evaluator**, seu assistente virtual. Atualmente me encontro em fase experimental. 
  
Para dúvidas ou sugestões, favor entrar em contato com o time de responsável.  
Para uma ajuda simplificada digite `/help`.    
  
Obrigado!