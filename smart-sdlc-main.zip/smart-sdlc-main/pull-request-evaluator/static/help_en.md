    
Here are the commands I understand:  

| **command**      | **description**                 |
|------------------|---------------------------------|
| /help            | Prints this message             |
| /prSummary       | Prints the Pull Request Summary |
| /diffSummary     | Prints a Summary of each Diff   |
| /diffRank        | Ranks each diff Risk            |
| /fileSummary     | Prints each file Summary        |
| /filePerformance | Report on each file Performance |
| /fileSecurity    | Report on each file Security    |
    
    