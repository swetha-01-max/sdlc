# evaluator

Aplicação/Serviço em NodeJS + Express para avaliar documentos de Use Story.  
