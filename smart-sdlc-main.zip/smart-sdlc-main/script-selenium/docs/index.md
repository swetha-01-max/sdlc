# script-selenium

Aplicação/Serviço em NodeJS + Express para gerar scripts de Testes em **Selenium**.
