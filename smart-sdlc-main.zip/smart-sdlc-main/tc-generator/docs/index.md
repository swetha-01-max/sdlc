# tc-generator

Aplicação/Serviço em NodeJS + Express para gerar documentos de Test Case para o time de Qualidade.  
Esta aplicação recebe como entrada o documento de **Estórias de Usuário** e utiliza-se da plataforma **Vertex AI** do **Google Cloud** para a geração de um documento com casos de teste.
